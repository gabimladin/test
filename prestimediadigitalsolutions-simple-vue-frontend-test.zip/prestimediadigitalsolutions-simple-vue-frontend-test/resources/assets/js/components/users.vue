<template>
    <div>
        
        <h1>{{ title }}</h1>
        
        <button :class="{'is-active': asc}"  @click="asc=!asc">Sort (ASC)</button>
        <button :class="{'is-active': desc}" @click="desc=!desc">Sort (DESC)</button>

        <div class="flex-grid">
            <div class="col" v-for="(user, i) in sorted" :key="'using-filter-'+i">
                {{ user.title | short_user }}
            </div>
        </div>

    </div>
</template>

<script>

    require('../app/app.store.js');
    const axios = require("axios");

    export default{
    	data: function () {
    	    return {
                title: 'Users page',
                asc: false,
                desc: false,
                infousers: []
            }
    	},
        created: function () {
            axios.get('https://jsonplaceholder.typicode.com/posts').then(response => (this.infousers = response.data))
        },
    	computed: {
            sorted() {
                if (this.asc) {
                    return this.infousers.slice().sort(function(a, b){
                        return (a.title > b.title) ? 1 : -1;
                    });

                } else if (this.desc) {
                    return this.infousers.slice().sort(function(a, b){
                        return (a.title > b.title) ? -1 : 1;
                    });
                }
                return this.infousers;
            },
    	},
        watch: {
                asc(newVal) {
                    if (this.desc && newVal)
                    this.desc = false
                },
                desc(newVal) {
                    if (this.asc && newVal)
                    this.asc = false
                },
        },
        filters: {
            short_user (title) {
                let short_user = title.split(' ').map(function(item){return item[0]}).join(' ').toUpperCase();
                return short_user
            }
        },
    	mounted: function () {
        },
        methods: { 
        }
    }
</script>