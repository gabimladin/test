<?php

namespace App\Http\Controllers;

class NumbersController extends Controller
{

    public function numbers($number)
    {
        $num = $number;
        $sum = 0;
        $number_is = array();
        if(is_numeric($num)){
            for($i=1;$i<$num;$i++){
                $temp=$i;
                if($num%$temp == 0)
                    $sum=$sum+$i;
            }

            if($sum == $num)
                $number_is["number_is"] = "perfect";
            else if($sum<$num)
                $number_is["number_is"] = "deficient";
            else
                $number_is["number_is"] = "abundant";
        }
        return json_encode($number_is);
    }
}